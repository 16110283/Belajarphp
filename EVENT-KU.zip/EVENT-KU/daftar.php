<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Gerobak Sayur</title>
    <link rel="stylesheet" href="css/Login.css"> 
    <link href="css/style.css" rel="stylesheet">
    <meta name="viewport" content="width=device-width , initial-scale=1">
  </head>
  <body background="img/login.jpg">

    <div id="register">
      <div class="body">

          <h2><a href="index.html" style="text-decoration:none">Gerobak Sayur</a></h2> 

          <form class="form" action="" method="post">
            <input class="user" type="text" name="username" placeholder="Nama Depan"><br>
            <input class="user" type="text" name="username" placeholder="Nama Belakang"><br>
            <input class="user" type="text" name="username" placeholder="No. Handphone"><br>
            <input class="user" type="Email" name="username" placeholder="Enter Email"><br>
            <input class="user" type="password" name="username" placeholder="Enter password"><br>

             <div class="g-recaptcha" data-sitekey="6LewXyITAAAAANN23aBYqfqY2VvjQV-TiKz0XCcZ"><div style="width: 304px; height: 78px;"><div><iframe src="https://www.google.com/recaptcha/api2/anchor?ar=1&amp;k=6LewXyITAAAAANN23aBYqfqY2VvjQV-TiKz0XCcZ&amp;co=aHR0cHM6Ly9saW1ha2lsby5pZDo0NDM.&amp;hl=en&amp;v=v1529908317173&amp;size=normal&amp;cb=vjpyac33j3mk" width="304" height="78" role="presentation" frameborder="0" scrolling="no" sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox"></iframe></div><textarea id="g-recaptcha-response" name="g-recaptcha-response" class="g-recaptcha-response" style="width: 250px; height: 40px; border: 1px solid #c1c1c1; margin: 10px 25px; padding: 0px; resize: none;  display: none; "></textarea></div></div>


            <button class="log-in" type="submit" name="login"><a href="index.php" style="text-decoration: none;">DAFTAR </a></button>
          </form>


          <div class="row">
            <div class="col-md-12">
              <a href="facebook.com" class="btn btn-facebook" style="text-decoration: none;"><center>Daftar dengan Facebook</center></a>
            </div>
          </div>

            <div class="row">
            <div class="col-md-12">
              <br>
              <center>atau</center>
            </div>
          </div>

          <div class="row">
            <div class="col-md-12">
              <a href="google.com" style="text-decoration: none;"><center>Daftar dengan Google</center></a>
            </div>
          </div>


          <div class="layout">
              <p style="text-decoration: none;">Sudah punya akun?</p>
            <a href="login.php" style="text-decoration:none;"><center>Silakan login</center></a>  <!-- Kurang link ke Login -->
          </div>
      </div>
    </div>

  </body>
</html>