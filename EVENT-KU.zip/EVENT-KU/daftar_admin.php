<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Event-KU</title>
    <link rel="stylesheet" href="css/Login.css"> 
    <link href="css/style.css" rel="stylesheet">
    <meta name="viewport" content="width=device-width , initial-scale=1">
  </head>
  <body background="img/login.jpg">

    <div id="register">
      <div class="body">

          <h2><a href="index.html" style="text-decoration:none">Event-Ku</a></h2> 

          <form class="form" action="aksidaftaradmin.php" method="POST">
            <input class="user" type="text" name="namad" placeholder="Nama Depan"><br>
            <input class="user" type="text" name="namab" placeholder="Nama Belakang"><br>
            <input class="user" type="text" name="hp" placeholder="No. Handphone"><br>
            <input class="user" type="Email" name="Email" placeholder="Enter Email"><br>
            <input class="user" type="password" name="pass" placeholder="Enter password"><br>

            

            <button class="log-in" type="submit" name="daftar"><a href="penjual_baru.php" style="text-decoration: none;">DAFTAR </a></button>
          </form>

        </div>
      </div>
    


  
  </body>
</html>