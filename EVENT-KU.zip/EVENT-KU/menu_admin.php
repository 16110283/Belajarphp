<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>EVENT-KU</title>
    <link rel="stylesheet" href="css/Login.css"> 
    <link href="css/style.css" rel="stylesheet">
   <link rel="icon" type="image/png" href="img/logo.png">
    <meta name="viewport" content="width=device-width , initial-scale=1">
  </head>
  <body background="img/login.jpg">

    <div id="login">
      <div class="body">

          <h2><a href="index.html" style="text-decoration:none">EVENT-KU</a></h2> 

    <form class="form" action="" method="post">
    <header>
        <h3>Pendaftaran Member Baru</h3>
        <h1>Event - Ku</h1>
    </header>
    </form>

    </p>
        <ul>
            <li><a href="daftar_admin.php">Daftar Member Baru</a></li>
            <li><a href="penjual_baru.php">Pendaftaran</a></li>
            <li><a href="login_admin.php">Log Out</a></li>
        </ul>
    </nav>

    </body>
</html>